﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Raqueta : MonoBehaviour {
	//Velocidad
	public float velocidad = 30.0f;
	//Eje vertical
	public string eje;
	public string ejex;
	// Es llamado una vez cada fixed frame
	void FixedUpdate () {
		//Capto el valor del eje vertical de la raqueta
		float v = Input.GetAxisRaw(eje);
		if (v != 0) {
			//Modifico la velocidad de la raqueta
			GetComponent<Rigidbody2D> ().velocity = new Vector2 (0, v * velocidad);
		} else {
			if(GameObject.Find("RaquetaIzquierda").transform.position.x >= -5 || GameObject.Find("RaquetaIzquierda").transform.position.x <= -58){
				GameObject.Find("RaquetaIzquierda").transform.position = new Vector2(-50,GameObject.Find("RaquetaIzquierda").transform.position.y);
			}else if(GameObject.Find("RaquetaDerecha").transform.position.x <= 5 || GameObject.Find("RaquetaDerecha").transform.position.x >= 58){
				GameObject.Find("RaquetaDerecha").transform.position = new Vector2(50,GameObject.Find("RaquetaDerecha").transform.position.y);
			}
			v = Input.GetAxisRaw(ejex);
			GetComponent<Rigidbody2D> ().velocity = new Vector2 (v * velocidad, 0);
		}
			
	}
}